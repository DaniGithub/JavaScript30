let menuList = document.querySelector('#menu-list');
let submitBtn = document.querySelector('input[type="submit"]');
let deleteBtn = document.querySelector('form ul li span');
let item = document.querySelector('#item');
let form = document.querySelector('form');
let itemsArray = [];
if(localStorage.itemsArray) {
	itemsArray = JSON.parse(localStorage.getItem('itemsArray'));
	console.log(itemsArray)
}


function addListItem(e) {
	e.preventDefault();
	if(item.value === '' || item.value === undefined) return;
	let html = `
		<li class="listItem">
			<input id="${itemsArray.length}" type="checkbox" data-checked="false" />
			<label for="${itemsArray.length}">${item.value}</label>
			<span>X</span>
		</li>
	`;
	itemsArray.push(html);

	populateList(menuList, itemsArray)
	form.reset();
};

function updateLocalStorage(key, value) {
	localStorage[key] = value;
}

function populateList(element, itemsArray = [], replace = false) {
	let menuList = document.querySelector('#menu-list');
	let index = itemsArray.length - 1;
	if(replace) {
		menuList.innerHTML = '';
		itemsArray.forEach(item => menuList.innerHTML += item);
		if(itemsArray.length === 1) itemsArray.length = 0;
	} else {
		menuList.innerHTML += itemsArray[index];
	}
	updateLocalStorage('itemsArray', JSON.stringify(itemsArray));
}

function fixIndices() {
	let inputElms = document.querySelectorAll('#menu-list input');
	inputElms.forEach((inputEl, i) => {
		inputEl.setAttribute('id', i);
	});
}

function deleteItem(e) {
	console.log('click')
	let parent = e.target.parentNode;
	parent.remove();
	fixIndices();
	let itemsArrayIndex = +parent.querySelector('input[type="checkbox"]').getAttribute('id');
	console.log(itemsArrayIndex)
	itemsArray.splice(itemsArrayIndex,1);
	
	populateList(menuList, itemsArray, true)
}



function checkCheckState(e) {
	if(e.target.dataset.checked === 'false') {
		state = 'true';
		e.target.setAttribute('checked', 'checked');
	} else {
		state = 'false';
		e.target.removeAttribute('checked');
	}
	e.target.dataset.checked = state;

	var idOfItemClicked = +e.target.getAttribute('id');
	itemsArray[idOfItemClicked] = e.target.parentNode.outerHTML;
	populateList(menuList, itemsArray, true);
}

function eventDelegation(e) {
	if(e.target.matches('span')) {
		deleteItem(e);
	}
	if(e.target.matches("input") || e.target.matches("label")) {
		if(e.target.matches("input")) {
			checkCheckState(e)
		}
	}

}

menuList.addEventListener('click', eventDelegation);
submitBtn.addEventListener('click', addListItem);

populateList(menuList, itemsArray, true);